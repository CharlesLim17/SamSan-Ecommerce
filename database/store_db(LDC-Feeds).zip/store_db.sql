-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 28, 2022 at 08:54 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `store_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `is_active` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`, `is_active`) VALUES
(1, 'Charles Angelo Lim', 'choylim06@gmail.com', '$2y$10$Kds8ICtmbJvi376jGfJky.2nH3K63H92Is/lTEeD2.C8wCbiFhhkO', '0'),
(2, 'Angelo Lim', 'kunwaringemail@gmail.com', '$2y$10$84XCKRKPxLvSM4DW7WBlxO0XGfZhFi5bkLpSD4JOpZa0SnQAlvVzW', '0');

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `brand_id` int(100) NOT NULL,
  `brand_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`brand_id`, `brand_title`) VALUES
(6, 'B-MEG'),
(7, 'Thunderbird'),
(8, 'Aquashare'),
(9, 'Nutrena'),
(10, 'GMP'),
(11, 'Hagibis'),
(12, 'Tateh'),
(13, 'Ideal'),
(14, 'Supple');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(10) NOT NULL,
  `p_id` int(10) NOT NULL,
  `ip_add` varchar(250) NOT NULL,
  `user_id` int(10) DEFAULT NULL,
  `qty` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `p_id`, `ip_add`, `user_id`, `qty`) VALUES
(10, 2, '::1', -1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(100) NOT NULL,
  `cat_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`) VALUES
(13, 'Pellets Sacks'),
(14, 'Pellets 1Kg'),
(15, 'Vitamins');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `trx_id` varchar(255) NOT NULL,
  `p_status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `product_id`, `qty`, `trx_id`, `p_status`) VALUES
(1, 1, 10, 1, '6B6839354S3341505', 'Completed'),
(2, 2, 2, 1, '7AP23648UX028115K', 'Completed'),
(3, 2, 7, 1, '7AP23648UX028115K', 'Completed');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(100) NOT NULL,
  `product_cat` int(11) NOT NULL,
  `product_brand` int(100) NOT NULL,
  `product_title` varchar(255) NOT NULL,
  `product_price` int(100) NOT NULL,
  `product_qty` int(11) NOT NULL,
  `product_desc` text NOT NULL,
  `product_image` text NOT NULL,
  `product_keywords` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_cat`, `product_brand`, `product_title`, `product_price`, `product_qty`, `product_desc`, `product_image`, `product_keywords`) VALUES
(2, 13, 6, 'BMEG Hog Grower', 1700, 500, '1234', '1645278194_hog-grower.png', 'bmeg'),
(3, 13, 6, 'BMEG Hog Finisher', 1650, 50, '1234', '1645278658_hog-finisher.png', 'bmeg'),
(4, 13, 6, 'BMEG Hog Starter', 1750, 100, '1234', '1645279281_hog-starter.jpg', 'bmeg'),
(5, 13, 6, 'BMEG Integra 1000', 1535, 40, '1234', '1645279421_integra-1.jpg', 'bmeg'),
(6, 13, 6, 'BMEG Integra 2000', 1470, 50, '1234', '1645279450_integra-2.jpg', 'bmeg'),
(7, 13, 6, 'BMEG Integra 3000', 1325, 50, '1234', '1645279487_integra-3.jpg', 'bmeg'),
(8, 13, 10, 'GMP Breeder ', 1350, 20, '1234', '1645279586_gmp-4.jpg', 'gmp'),
(9, 13, 9, 'NUTRENA Flyermix', 890, 60, '1234', '1645279771_flyermix-nutrena.png', 'nutrena'),
(10, 13, 12, 'TATEH Grower', 855, 50, '1234', '1645279877_tateh-grower.jpg', 'tateh'),
(11, 13, 12, 'TATEH Starter', 875, 50, '1234', '1645280246_tateh-starter.jpg', 'tateh'),
(12, 13, 12, 'TATEH Finisher', 840, 50, '1234', '1645280300_tateh-finisher.jpg', 'tateh'),
(13, 13, 12, 'TATEH Pre-Starter', 880, 50, '1234', '1645280328_tateh-pre-starter.jpg', 'tateh'),
(14, 13, 8, 'Aquashare Finisher', 870, 50, '1234', '1645280412_aquashare-finisher.jpg', 'aquashare'),
(15, 13, 8, 'Aquashare Grower', 875, 50, '1234', '1645280444_aquashare-grower.jpg', 'aquashare'),
(16, 13, 6, 'BMEG Fingerling', 840, 50, '1234', '1645280529_bmeg-fish-starter.jpg', 'bmeg'),
(17, 13, 6, 'BMEG Juvenile', 815, 50, '1234', '1645280575_bmeg-fish-grower.jpg', 'bmeg'),
(18, 13, 6, 'BMEG Fish Finisher', 785, 50, '1234', '1645280680_bmeg-fish-finisher.jpg', 'bmeg'),
(19, 13, 13, 'Ideal Fry Mass', 860, 50, '1234', '1645280764_ideal-fish.jpg', 'ideal'),
(20, 13, 10, 'GMP Maintenance', 1350, 50, '1234', '1645280802_gmp-3.jpg', 'gmp'),
(21, 13, 7, 'Thunderbird Enertone', 860, 50, '1234', '1645280838_enertone-sack.jpg', 'thunderbird'),
(22, 13, 6, 'C1 Grinded Corn', 1020, 50, '1234', '1645280884_c1-grinded-corn.jpg', 'bmeg'),
(23, 13, 6, 'C3 Cracked Corn', 1200, 50, '1234', '1645280911_c3-cracked-corn.jpg', 'bmeg'),
(24, 13, 11, 'Hagibis Super Conditioner', 800, 50, '1234', '1645280955_hagibis.jpg', 'hagibis'),
(25, 14, 7, 'Thunderbird Stag Developer', 42, 1000, '1234', '1645280995_stag-dev-4.jpg', 'thunderbird'),
(26, 14, 7, 'Thunderbird Enertone 1KG', 34, 1000, '1234', '1645281033_enertone-kg.jpg', 'thunderbird'),
(27, 14, 7, 'Thunderbird Platinum', 52, 1000, '1234', '1645281069_platinum.jpg', 'thunderbird'),
(28, 14, 7, 'Thunderbird Stag Developer', 48, 1000, '1234', '1645281118_chick-booster.jpg', 'thunderbird'),
(29, 15, 14, 'Hammer Anthelmintic 200pcs/box', 1200, 1000, '1234', '1645281196_vit-hammer.jpg', 'vitamins'),
(30, 15, 14, 'Vetracin Classic 48pcs/box', 860, 500, '1234', '1645281241_vit-vetra.jpg', 'vitamins'),
(31, 15, 14, 'Ambroxitil 48pcs/box', 1740, 500, '1234', '1645281278_vit-ambro.png', 'vitamins'),
(32, 15, 14, 'Washout Intense 24pcs/box', 390, 500, '1234', '1645281308_vit-washout.jpg', 'vitamins');

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `user_id` int(10) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address1` varchar(300) NOT NULL,
  `address2` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`user_id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `address1`, `address2`) VALUES
(1, 'Charles', 'Lim', 'ewanewan@gmail.com', '153dd7ee2ce2927ec99b59812a5f1614', '9056601728', '1 Hubilla St. Pinaglabanan Ext.', 'xxx'),
(2, 'Angelo', 'Lim', 'ewanko@gmail.com', 'd78e3a2925d7e20c5fba1c68a02c4e2f', '9526325879', 'qwe', 'yy');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `fk_product_cat` (`product_cat`),
  ADD KEY `fk_product_brand` (`product_brand`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `brand_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fk_product_brand` FOREIGN KEY (`product_brand`) REFERENCES `brands` (`brand_id`),
  ADD CONSTRAINT `fk_product_cat` FOREIGN KEY (`product_cat`) REFERENCES `categories` (`cat_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
